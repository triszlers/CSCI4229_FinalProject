#pragma once

class Tools{
public:


    void Print(const char* text, ...);

private:
    int id;
};